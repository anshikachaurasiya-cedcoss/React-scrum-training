interface OrderI {
    "_id"?:number
    // [name : string] : string | number
}

export { OrderI };