import React from 'react';

const CampaignPage = () => {
    return (
        <>
            <h2>Create Campaign Page</h2>
        </>
    );
};

export default CampaignPage;
